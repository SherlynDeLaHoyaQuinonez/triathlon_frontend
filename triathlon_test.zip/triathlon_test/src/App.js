import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, Outlet } from 'react-router-dom'; // Importar Routes
import './App.css';

function ParticipantsList({ participants }) {
  return (
    <div>
      <h2>Participantes Registrados:</h2>
      <ul>
        {participants.map((participant, index) => (
          <li key={index}>{participant}</li>
        ))}
      </ul>
    </div>
  );
}

function EventDetails({ events }) {
  return (
    <div>
      <h2>Detalles del Evento</h2>
      {events.map((event, index) => (
        <div key={index}>
          <p><strong>Nombre del Evento:</strong> {event.name}</p>
          <p><strong>Fecha:</strong> {event.date}</p>
          <p><strong>Ubicación:</strong> {event.location}</p>
          <Link to={`/event/${index}/participantsList`}>Ver Participantes</Link>
        </div>
      ))}
      <Outlet /> {/* Agregar Outlet para mostrar subrutas */}
    </div>
  );
}

function App() {
  const [events] = useState([
    {
      name: 'Natación',
      date: '2023-10-15',
      location: 'Piscina Olímpica',
      participants: ['Nadador 1', 'Nadadora 2', 'Nadador 3'],
    },
    {
      name: 'Atletismo',
      date: '2023-10-20',
      location: 'Estadio Nacional',
      participants: ['Atleta 1', 'Atleta 2', 'Atleta 3'],
    },
  ]);

  return (
    <Router>
      <div className="App">
        <header className="App-header">
          <h1>Eventos</h1>
        </header>
        <nav>
          <ul>
            {events.map((event, index) => (
              <li key={index}>
                <Link to={`/event/${index}`}>{event.name}</Link>
              </li>
            ))}
          </ul>
        </nav>
        <Routes> {/* Usar Routes para envolver las rutas */}
          <Route path="/event/:id" element={<EventDetails events={events} />} />
          <Route path="/event/:id/participants" element={<ParticipantsList events={events} />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
